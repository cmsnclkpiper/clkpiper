@extends('layout.app')
@section('title','Welcome')
@section('body')
    Welcome to Laravel 5.4
@endsection