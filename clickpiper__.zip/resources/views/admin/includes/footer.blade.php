</div>
        <!-- footer content -->
        <footer>
          <div class="pull-right') }} ">
            Design & developed By CMSN Network LTD <a href="http://cmsnbd.com">CMSN Network</a>
          </div>
          <div class="clearfix') }} "></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="{{ URL::asset('admin/vendors/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap -->
    <script src="{{ URL::asset('admin/vendors/bootstrap/dist/js/bootstrap.min.js') }} "></script>
    
     <!-- jQuery -->
    <script src="{{ URL::asset('admin/vendors/ckeditor/ckeditor.js') }}"></script>
    
    <!-- FastClick -->
    <script src="{{ URL::asset('admin/vendors/fastclick/lib/fastclick.js') }} "></script>
    <!-- NProgress -->
    <script src="{{ URL::asset('admin/vendors/nprogress/nprogress.js') }} "></script>
    <!-- Chart.js -->
    <script src="{{ URL::asset('admin/vendors/Chart.js/dist/Chart.min.js') }} "></script>
    <!-- gauge.js -->
    <script src="{{ URL::asset('admin/vendors/gauge.js/dist/gauge.min.js') }} "></script>
    <!-- bootstrap-progressbar -->
    <script src="{{ URL::asset('admin/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js') }} "></script>
    <!-- iCheck -->
    <script src="{{ URL::asset('admin/vendors/iCheck/icheck.min.js') }} "></script>
    <!-- Skycons -->
    <script src="{{ URL::asset('admin/vendors/skycons/skycons.js') }} "></script>
    <!-- Flot -->
    <script src="{{ URL::asset('admin/vendors/Flot/jquery.flot.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/Flot/jquery.flot.pie.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/Flot/jquery.flot.time.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/Flot/jquery.flot.stack.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/Flot/jquery.flot.resize.js') }} "></script>
    <!-- Flot plugins -->
    <script src="{{ URL::asset('admin/vendors/flot.orderbars/js/jquery.flot.orderBars.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/flot-spline/js/jquery.flot.spline.min.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/flot.curvedlines/curvedLines.js') }} "></script>
    <!-- DateJS -->
    <script src="{{ URL::asset('admin/vendors/DateJS/build/date.js') }} "></script>
    <!-- JQVMap -->
    <script src="{{ URL::asset('admin/vendors/jqvmap/dist/jquery.vmap.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/jqvmap/dist/maps/jquery.vmap.world.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js') }} "></script>
    <!-- bootstrap-daterangepicker -->
    <script src="{{ URL::asset('admin/vendors/moment/min/moment.min.js') }} "></script>
    <script src="{{ URL::asset('admin/vendors/bootstrap-daterangepicker/daterangepicker.js') }} "></script>

    <!-- Custom Theme Scripts -->
    <script src="{{ URL::asset('admin/build/js/custom.min.js') }} "></script>
	
  </body>
</html>
