<?php

namespace App\Http\Controllers;


use App\Subcategory;
use App\Categorie;

class SubCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:administration');
    }

    public function index(){
        $subcategories = Subcategory::all();
        $categories = Categorie::all();
        return view('admin.subcategories.index', compact('subcategories', 'categories'));
    }
}