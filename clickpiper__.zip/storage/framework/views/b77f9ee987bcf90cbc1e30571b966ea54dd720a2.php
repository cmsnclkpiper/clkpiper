     <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Title -->
        <div class="page-title-container">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 wow fadeIn">
                        <i class="fa fa-envelope"></i>
                        <h1>Our Blog /</h1>
                        
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Us -->
        <div class="contact-us-container">
		<!-- PART ONE-->

        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
		<div class="container">
	            <div class="row">
				<div class="col-md-1"></div>
				 <div class="col-md-10">
					<div class="panel panel-default">
					  <div class="panel-heading phead"><?php echo e($blog->title); ?></div>
					  <div class="panel-body"><?php echo $blog->short_desc; ?> 
					  <table>
					  <tr>
					  <td><i class="fa fa-user" aria-hidden="true"></i></td>

					  <td class="bloguser"><?php echo e($blog->postBy); ?></td>
					  
					  </tr>
					  </table>
					 
					  </div>
					</div>
				 </div>
				 <div class="col-md-1"></div>
				</div>
				
		</div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
 <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>