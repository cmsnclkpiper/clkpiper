 <!-- /. PAGE WRAPPER  -->
		<!-- Footer -->
        <footer style="background-color:#000">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 footer-box wow fadeInUp fb" style="padding-top:10px;"> 
					   <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
					    <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
						<a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
						<a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
					 </div>
					   
                     <div class="col-sm-4 footer-box wow fadeInDown">
                       <div class="footer-copyright wow fadeIn">
                        <p style="color:#fff; font-size:12px;">Powered by: Teck Today &copy 2017 click piper </p>
                    </div>
                    </div>
					
                    <div class="col-sm-4 footer-box wow fadeInDown footer-menu">
                     
							<table class="table">
							<tr>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">About Us</a></td>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">FAQ</a></td>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">Blog</a></td>
							</tr>
							
							<tr>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">Contact Us</a></td>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">Privacy policy</a></td>
							<td class="tabletr1"><a href="#" target="_blank"target="_blank">User terms</a></td>
							</tr>
							</table>
							
                    </div>
                
			</div>
			</div>
        </footer>

        <!-- Javascript -->
      
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   
    <!-- Metis Menu Js -->
    <script src="<?php echo e(URL::asset('frontend/user/js/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo e(URL::asset('frontend/user/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/user/js/jquery.metisMenu.js')); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo e(URL::asset('frontend/user/js/morris/raphael-2.1.0.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/user/js/morris/morris.js')); ?>"></script>
    <!-- Custom Js -->
    <script src="<?php echo e(URL::asset('frontend/user/js/custom-scripts.js')); ?>"></script>


</body>

</html>