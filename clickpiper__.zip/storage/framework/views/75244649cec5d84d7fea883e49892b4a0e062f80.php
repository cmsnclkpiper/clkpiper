<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row tile_count">
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-users"></i> Total Users</span>
              <div class="count"><?php echo e($totalUsers); ?></div>
            </div>
            
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-connectdevelop"></i> Total Offers</span>
              <div class="count"><?php echo e($totalOffers); ?></div>
            </div>
            
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-question"></i> Total Faqs</span>
              <div class="count"><?php echo e($totalFaqs); ?></div>
            </div>
            
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-newspaper-o"></i> Total Posts</span>
              <div class="count"><?php echo e($totalBlogs); ?></div>
            </div>
            
          </div>
         

          <div class="row">


            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="x_panel tile fixed_height_320" style="box-shadow:#F37653 0 0 1px 1px">
                <div class="x_title">
                  <h2>Last Registered User</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                  <tr>
                      <th>SI</th>
                        <th>Name</th>
                        <th>City</th>
                        <th>Created</th>
                    </tr>
                     <?php $i=1; ?>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($menu->fname.' '.$menu->fname); ?></td>
                        <td><?php echo e($menu->city); ?></td>
                        <td><?php echo e($menu->created_at); ?></td>
                    </tr>
                     
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </table>
                  

                </div>
              </div>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="x_panel tile fixed_height_320" style="box-shadow:#F37653 0 0 1px 1px">
                <div class="x_title">
                  <h2>Latest Blog Post</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                  <tr>
                        <th>SI</th>
                        <th>Title</th>
                        <th>Created</th>
                    </tr>
                   <?php $i=1; ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($menu->title); ?></td>
                        <td><?php echo e($menu->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </table>
                  

                </div>
              </div>
            </div>


            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="x_panel tile fixed_height_320" style="box-shadow:#F37653 0 0 1px 1px">
                <div class="x_title">
                  <h2>Today Offers</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                  <tr>
                      <th>SI</th>
                        <th>Title</th>
                        <th>Points</th>
                        <th>Created</th>
                    </tr>
                    
                     <?php $i=1; ?>
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($menu->title); ?></td>
                        <td><?php echo e($menu->points); ?></td>
                        <td><?php echo e($menu->created_at); ?></td>
                    </tr>
                     
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
                 </table>
                  

                </div>
              </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="x_panel tile fixed_height_320" style="box-shadow:#F37653 0 0 1px 1px">
                <div class="x_title">
                  <h2>FAQ</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                  <tr>
                      <th>SI</th>
                        <th>Question</th>
                        <th>Created</th>
                    </tr>
                     <?php $i=1; ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($faq->question); ?></td>
                      <td><?php echo e($faq->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                 </table>
                  

                </div>
              </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <div class="x_panel tile fixed_height_320" style="box-shadow:#F37653 0 0 1px 1px">
                <div class="x_title">
                  <h2>Highest Converting Offers</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                  <tr>
                      <th>SI</th>
                        <th>Title</th>
                        <th>Points</th>
                        <th>Created</th>
                    </tr>
                    
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($menu->title); ?></td>
                      <td><?php echo e($menu->points); ?></td>
                      <td><?php echo e($menu->created_at); ?></td>
                    </tr>                     
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                 </table>
                  

                </div>
              </div>
            </div>
            

          </div>


          
        </div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>