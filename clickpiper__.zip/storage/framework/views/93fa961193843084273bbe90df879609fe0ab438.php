<?php echo $__env->make('layouts.user-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper" style="background-color:#ffffff !important; height:auto !important;">
    <div id="page-inner">
        <div class="row">
          <div class="col-sm-10">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <h2 style="text-align:left; margin:13px">Counter Shop</h2>
                    <hr>
                    <div class="row">                      
                        <div class="col-sm-3">
                          <input type="button" name="submit" class="btn btn-primary" onclick="search_offer();" value="Terms" />
                        </div>
                        <div class="col-sm-3">
                          <input type="button" name="submit" class="btn btn-success" onclick="search_offer();" value="Order to Convert" />
                        </div>
                        <div class="col-sm-3">
                          <input type="button" name="submit" class="btn btn-info" onclick="search_offer();" value="Payment Request" />
                        </div>
                        <div class="col-sm-3">
                          <input type="button" name="submit" class="btn btn-warning" onclick="search_offer();" value="My Payments" />
                        </div>
                    </div>
                    <hr>
                </div>
                <!-- <div id="responseData" class="col-sm-12" style="margin-top:20px;"> -->
                    
                <table width="100%" class="table table-responsive bordered">
                  <tr style="background: #FF7607; color: #fff">
                      <th>Request Date</th>
                      <th>Approve Date</th>
                      <th>Request Amount</th>
                      <th>Payment Fees(2%)</th>
                      <th>Paid Amount</th>
                      <th>Method</th>
                  </tr>
                  <tr>
                    <td>07/01/2017</td>
                    <td>--</td>
                    <td>$150</td>
                    <td>--</td>
                    <td>--</td>
                    <td>PayPal</td>
                  </tr>
                  <tr>
                    <td>06/01/2017</td>
                    <td>06/04/2017</td>
                    <td>$200</td>
                    <td>$4</td>
                    <td>$196</td>
                    <td>PayPal</td>
                  </tr>
                  <tr style="font-weight: bold; font-size: 16px;">
                    <td colspan="2">06/01/2017 to 07/01/2017</td>
                    <td>$350</td>
                    <td>$4</td>
                    <td>$196</td>
                    <td></td>
                  </tr>
                  
                </table>


                </div>
            </div>
            <!--leftbar -->                    
            
        </div>
        <!-- /. ROW  -->
    <!--<footer><p>Powered By: TechToday &copy 2017 <a href="#">click piper</a></p></footer>--> 
    </div>
    <!-- /. PAGE INNER  -->
</div>       
       
                                        
<?php echo $__env->make('layouts.user-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>