<?php echo $__env->make('layouts.user-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
function search_offer(){
	var country = $("#country").val();	
	var category = $("#category").val();
	var date = $("#date").val();
	
	//alert(date);
	$.ajax({
		url:"<?php echo e(url('user/offer_filtering')); ?>",
		type:'GET',
		data:{'country':country,'category':category,'date':date},
		success:function(response){
			//alert(response);
			$("#responseData").html(response);
		},
		error:function(){
			alert(0);
		}
	});
}
</script>
<div id="page-wrapper" style="background-color:#ffffff !important; height:auto !important;">
    <div id="page-inner">
        <div class="row">
        	<div class="col-sm-10">
                <div class="col-md-12 col-sm-12 col-xs-12">
                 	<h2 style="text-align:left; margin:13px">Browse Offer</h2>
                    <hr>
                    <div class="row">
                    	<div class="col-sm-3">
                            <select name="country" id="country" class="custom-input">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                	<option value="<?php echo e($count->name); ?>"><?php echo e($count->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                        </div>
                        <div class="col-sm-3">
                        	<select name="category" id="category" class="custom-input">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($count->cat_name); ?>"><?php echo e($count->cat_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-sm-3">
                        	<input type="date" name="searchoffer" id="date" class="custom-input" placeholder="Date" style="padding:2px 5px"/>
                        </div>
                        <div class="col-sm-3">
                        	<input type="button" name="submit" class="btn btn-success" style="font-size:25px" onclick="search_offer();" value="Search" />
                        </div>
                    </div>
                    <hr>
                </div>
                <div id="responseData" class="col-sm-12" style="margin-top:20px;">
                    
                    <table width="100%" class="table table-responsive bordered">
      <tr style="background: #FF7607; color: #fff">
          <th>SI</th>
            <th>Top offer</th>
            <th>Rewards</th>
        </tr>
         <?php $i=1; ?>
        <?php $__currentLoopData = $topOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
          <tr>
          <td><?php echo e($menu->id); ?></td>
           <td><a href="javascript:void();" data-toggle="modal" data-target="#topOffers<?php echo e($i); ?>"><?php echo e($menu->title); ?> </a>
            <div id="topOffers<?php echo e($i); ?>" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo e($menu->title); ?></h4>
                  </div>
                  <div class="modal-body">
                    <table width="100%" class="table">
                        <tr>
                            <td width="23%">Offer</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->title); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Banner Image</td>
                            <td width="2%"> : </td>
                            <td width="75%">
                            <img src="<?php echo e(URL::asset('admin/uploads/offer/'.$menu->image)); ?>" style="width:100px; height:auto" /></td>
                      </tr>
                      <tr>
                            <td width="23%">Details</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo $menu->full_desc; ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Action Link</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->action_link); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Conversation Points</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->points); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Category</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->category); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Allowed Country</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->allowed_country); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Date</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->date); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Rewards Amounts</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->rewards_amount); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Note</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo $menu->note; ?></td>
                      </tr>
                    </table>
                  </div>
                 
                </div>
            
              </div>
            </div>
          </td>
          <td><?php echo e($menu->points); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
     </table>


                </div>
            </div>
            <!--leftbar -->                    
            
        </div>
        <!-- /. ROW  -->
    <!--<footer><p>Powered By: TechToday &copy 2017 <a href="#">click piper</a></p></footer>--> 
    </div>
    <!-- /. PAGE INNER  -->
</div>       
       
                                      	
<?php echo $__env->make('layouts.user-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>