   <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Title -->
        <div class="page-title-container">
            <div class="container">
                <div class="row">
                    <div  style="text-align: center;" class="col-sm-12 wow fadeIn">
                        <i class="fa fa-lock"></i>
                        <h1>Login</h1>                        
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Us -->
        <div class="contact-us-container">
		<div class="container">
	       <div class="row">
			<div class="col-md-1"></div>
				  <div class="col-md-10">
						<div class="wrapper">




                             <form class="form-signin" method="POST" action="<?php echo e(route('user.login.submit')); ?>">
                       			 <?php echo e(csrf_field()); ?>       
								<h3 class="form-signin-heading">Welcome Back! Please Sign In</h3>
								  <hr class="colorgraph"><br>							  
                                  
                                  <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
								  	<input style="background-color:#fff;" type="text" class="form-control" name="email" placeholder="Username" 
                                    value="<?php echo e(old('email')); ?>" required autofocus />
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                	<?php endif; ?>
                                  </div>
                                  <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
								  	<input type="password" class="form-control" name="password" placeholder="Password" required/>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                	<?php endif; ?>
                                  </div>
                                  
                                  
                                    		  	 
								  <button class="btn btn-lg btn-primary btn-block"  name="submit" value="Login" type="submit">Login</button><br>
                                  <div class="col-sm-6"><input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> > Remember Me</div>
								  <div class="col-sm-6" style="padding-top:5px"><a href="<?php echo e(route('password.request')); ?>">Forgot password?</a></div>						  
							</form>	

                         

														
						</div>
				 </div>
				 <div class="col-md-1"></div>
				
	    </div>
        </div>

        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>