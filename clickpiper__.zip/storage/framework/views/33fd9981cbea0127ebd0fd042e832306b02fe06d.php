<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="right_col" role="main">
          <!-- top tiles -->
          
         

          <div class="row">


            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Menu List</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-responsive bordered">
                 	<tr>
                    	<th>SI</th>
                        <th>Name</th>
                        <th>City</th>
                    </tr>
                    <tr>
                    	<td>01</td>
                        <td>Mohammad Wasim</td>
                        <td>Dhaka</td>
                    </tr>
                    <tr>
                    	<td>02</td>
                        <td>Sayeed</td>
                        <td>Dhaka</td>
                    </tr>
                    
                     <tr>
                    	<td>03</td>
                        <td>Mohammad Wasim</td>
                        <td>Dhaka</td>
                    </tr>
                    <tr>
                    	<td>04</td>
                        <td>Sayeed</td>
                        <td>Dhaka</td>
                    </tr>
                     <tr>
                    	<td>05</td>
                        <td>Mohammad Wasim</td>
                        <td>Dhaka</td>
                    </tr>
                    <tr>
                    	<td>06</td>
                        <td>Sayeed</td>
                        <td>Dhaka</td>
                    </tr>
                     <tr>
                    	<td>01</td>
                        <td>Mohammad Wasim</td>
                        <td>Dhaka</td>
                    </tr>
                    <tr>
                    	<td>02</td>
                        <td>Sayeed</td>
                        <td>Dhaka</td>
                    </tr>
                 </table>
                  

                </div>
              </div>
            </div>

         
          </div>


          
        </div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>