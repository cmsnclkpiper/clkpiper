<?php echo $__env->make('admin.includes.tophead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body>
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('administrator.login')); ?>">
                        <?php echo e(csrf_field()); ?>

              
              <h1>Admin Login</h1>
              <div class="col-sm-12">
                <input type="text" class="form-control" placeholder="Username"  name="email" value="<?php echo e(old('email')); ?>" required autofocus />
                 <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
              <div class="col-sm-12">
                <input type="password" class="form-control" placeholder="Password" name="password" required />
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
              <div class="col-sm-12">
                <div class="col-sm-6 pull-left"  style="margin:0; padding:0"><input type="submit" class="btn btn-submit" value="Login"></div>
                <div class="col-sm-6 pull-right" style="margin:0; padding:0"><a class="reset_pass" href="<?php echo e(route('password.request')); ?>">Lost your password?</a></div>
              </div>

              <div class="clearfix"></div>

              
            </form>
          </section>
        </div>

        
      </div>
    </div>
  </body>
</html>
