<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="right_col" role="main">
          <!-- top tiles -->
          
          <div class="x_title">
                  <h2>New Offer</h2>
                 
                  <div class="clearfix"></div>
                </div>
          <div class="x_content">
          	<?php echo Form::open(['url'=>'administrator/offer','files' => true, 'class'=>'form-horizontal']); ?>

            
          	  <div class="col-sm-12">
                <div class="row">
                
                     <div class="form-group">
                        <?php echo Form::label('title','Title', ['class'=>'control-label col-md-2']); ?>

                        <div class="col-md-9">
                            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('title')?$errors->first('title'):''; ?>

                        </div>
                    </div>
                  			 
                      <div class="form-group">
                        <?php echo Form::label('action_link','Action LInk', ['class'=>'control-label col-md-2']); ?>

                        <div class="col-md-9">
                            <?php echo Form::text('action_link', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('action_link')?$errors->first('action_link'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('points','Points', ['class'=>'control-label col-md-2']); ?>

                        <div class="col-md-9">
                            <?php echo Form::text('points', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('points')?$errors->first('points'):''; ?>

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <?php echo Form::label('rewards_amount','Rewards Amount', ['class'=>'control-label col-md-2']); ?>

                        <div class="col-md-9">
                            <?php echo Form::text('rewards_amount', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('rewards_amount')?$errors->first('rewards_amount'):''; ?>

                        </div>
                    </div>
                    
                    
                  
                    <div class="form-group">
                    
                        <?php echo Form::label('full_desc','Full Description', ['class'=>'control-label col-md-2']); ?>

                         <div class="col-md-9">
                           <textarea name="full_desc" class="form-control ckeditor"></textarea>
                            <?php echo $errors->has('full_desc')?$errors->first('full_desc'):''; ?>

                        </div>
                    </div>
                    
                    <div class="form-group">
                    
                        <?php echo Form::label('note','Note', ['class'=>'control-label col-md-2']); ?>

                         <div class="col-md-9">
                           <textarea name="note" class="form-control ckeditor"></textarea>
                            <?php echo $errors->has('note')?$errors->first('note'):''; ?>

                        </div>
                    </div>
   
   					<div class="form-group">
                        <?php echo Form::label('country','Country', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            
                            <select name="country" class="form-control">
                            	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<option value="<?php echo e($count->name); ?>"><?php echo e($count->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->has('country')?$errors->first('country'):''; ?>

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <?php echo Form::label('category','Category', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <select name="category" class="form-control">
                            	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<option value="<?php echo e($count->cat_name); ?>"><?php echo e($count->cat_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->has('category')?$errors->first('category'):''; ?>

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <?php echo Form::label('photo','Photo', ['class'=>'control-label col-md-2']); ?>

                         <div class="col-md-9">
                            <?php echo Form::file('photo', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('photo')?$errors->first('photo'):''; ?>

                        </div>
                    </div>
			
                     

					
              </div>
           		<div class="form-group">
				<div class="col-md-10 col-md-offset-5" style="margin-top:20px;">
					<?php echo Form::submit('Save', ['class'=>'btn btn-success']); ?>

                    <?php echo Form::reset('Reset', ['class'=>'btn btn-danger']); ?>

				</div>
			</div>
              </div>
              <?php echo Form::close(); ?>	 
			</div>

          
        </div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>