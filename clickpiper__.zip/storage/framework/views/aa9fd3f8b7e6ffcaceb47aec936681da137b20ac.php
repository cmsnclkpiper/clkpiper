<?php echo $__env->make('admin.includes.tophead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <body class="nav-md">

  <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="background:#fff">
              <a href="<?php echo e(url('/administrator/dashboard')); ?>">
              	<img src="<?php echo e(URL::asset('frontend/img/logo.png')); ?>" alt="...">
              </a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              
              
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="index.html">Dashboard</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> Administration <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('administrator.create')); ?>">New Admin</a></li>
                      <li><a href="<?php echo e(route('administrator.adminlist')); ?>">Admin List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-users"></i> Member <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('member.create')); ?>">New Member</a></li>
                      <li><a href="<?php echo e(route('member.index')); ?>">Member List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> Menu <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('menus.create')); ?>">New Menu Item</a></li>
                      <li><a href="<?php echo e(route('menus.index')); ?>">Menu List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> Content <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('contents.create')); ?>">New Content</a></li>
                      <li><a href="<?php echo e(route('contents.index')); ?>">Content List</a></li>
                    </ul>
                  </li>
                 <li><a><i class="fa fa-users"></i> Offer <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('categories.create')); ?>">New Category</a></li>
                      <li><a href="<?php echo e(route('categories.index')); ?>">Category List</a></li>
                      <li><a href="<?php echo e(route('subcategories.create')); ?>">New Sub-Category</a></li>
                      <li><a href="<?php echo e(route('subcategories.index')); ?>">Sub-Category List</a></li>
                      <li><a href="<?php echo e(route('offer.create')); ?>">New Offer</a></li>
                      <li><a href="<?php echo e(route('offer.index')); ?>">Offer List</a></li>
                    </ul>
                  </li>
                 <li><a><i class="fa fa-users"></i> Blog <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('blog.create')); ?>">New Blog</a></li>
                      <li><a href="<?php echo e(route('blog.index')); ?>">Blog List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> Faq <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('faqs.create')); ?>">New Question</a></li>
                      <li><a href="<?php echo e(route('faqs.index')); ?>">Question List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> Directors <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(route('director.create')); ?>">New Director</a></li>
                      <li><a href="<?php echo e(route('director.index')); ?>">Directors' List</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              
               <a data-toggle="tooltip" data-placement="top" title="Logout" 
               href="<?php echo e(route('administrator.logout')); ?>" onClick="event.preventDefault(); document.getElementById('logout-form').submit();">
                           <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            <?php if(Auth::check()): ?>
                             <?php echo e(Auth::user()->name); ?>

                            <?php endif; ?>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('administrator.logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo e(URL::asset('admin/images/img.jpg')); ?>"  alt="<?php if(Auth::check()): ?>
                             <?php echo e(Auth::user()->name); ?>

                            <?php endif; ?>"><?php if(Auth::check()): ?>
                             <?php echo e(Auth::user()->name); ?>

                            <?php endif; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    
                    <li>                    
                     <a href="<?php echo e(route('user.logout')); ?>" onClick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa fa-sign-out pull-right"></i> Log Out
                        </a>

                        <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                  </ul>
                </li>

                <li role="presentation" class="dropdown">
                 
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <li>
                      <a>
                        <span class="image"><img src="<?php echo e(URL::asset('admin//images/img.jpg')); ?>"  alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="<?php echo e(URL::asset('admin//images/img.jpg')); ?>" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="<?php echo e(URL::asset('admin//images/img.jpg')); ?>" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="<?php echo e(URL::asset('admin//images/img.jpg')); ?>" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
