<table width="100%" class="table table-responsive bordered">
      <tr style="background: #FF7607; color: #fff">
          <th>SI</th>
            <th>Top offer</th>
            <th>Rewards</th>
        </tr>
         <?php $i=1; ?>
        <?php $__currentLoopData = $allOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($i++); ?></td>
           <td><a href="javascript:void();" data-toggle="modal" data-target="#topOffers<?php echo e($i); ?>"><?php echo e($menu->title); ?> </a>
            <div id="topOffers<?php echo e($i); ?>" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo e($menu->title); ?></h4>
                  </div>
                  <div class="modal-body">
                    <table width="100%" class="table">
                        <tr>
                            <td width="23%">Offer</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->title); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Banner Image</td>
                            <td width="2%"> : </td>
                            <td width="75%">
                            <img src="<?php echo e(URL::asset('admin/uploads/offer/'.$menu->image)); ?>" style="width:100px; height:auto" /></td>
                      </tr>
                      <tr>
                            <td width="23%">Details</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo $menu->full_desc; ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Action Link</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->action_link); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Conversation Points</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->points); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Category</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->category); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Allowed Country</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->allowed_country); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Date</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->date); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Rewards Amounts</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo e($menu->rewards_amount); ?></td>
                      </tr>
                      <tr>
                            <td width="23%">Note</td>
                            <td width="2%"> : </td>
                            <td width="75%"><?php echo $menu->note; ?></td>
                      </tr>
                    </table>
                  </div>
                 
                </div>
            
              </div>
            </div>
          </td>
          <td><?php echo e($menu->points); ?></td>
        </tr>
         
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
     </table>
