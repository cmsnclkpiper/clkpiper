<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="right_col" role="main">
  <!-- top tiles -->
  <div class="row">

    <div class="col-md-12 col-sm-12 col-xs-12">

      <div class="x_panel tile">

        <div class="x_title">
          
          <h2>Menu List</h2>
          <div class="clearfix"></div>
          <hr>
          <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-primary">Add Menu Item</a>

        </div>

        <div class="x_content">

          <table width="100%" class="table table-responsive bordered">

          	<tr>
            	<th>Menu Name</th>
              <th>Slug</th>
              <th>Sequence</th>
              <th>Status</th>
              <th>Url</th>
              <th colspan="2">Actions</th>
            </tr>

            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            	<td><?php echo e($menu->menuname); ?></td>
              <td><?php echo e($menu->slug); ?></td>
              <td><?php echo e($menu->sequence); ?></td>
              <td><?php echo e($menu->status); ?></td>
              <td><?php echo e($menu->menu_url); ?></td>
              <td><a href="<?php echo e(route('menus.edit', $menu->id)); ?>" class="btn btn-warning" style="font-size: 12px;">Edit</a></td>
              <td><?php echo Form::open(['method'=>'delete', 'route'=>['menus.destroy', $menu->id]]); ?>

            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger custom-delete-button', 'onclick'=>'return confirm("Are you sure you want to delete this record?")']); ?>

            <?php echo Form::close(); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>

        </div>

      </div>

    </div>

  </div>

</div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>