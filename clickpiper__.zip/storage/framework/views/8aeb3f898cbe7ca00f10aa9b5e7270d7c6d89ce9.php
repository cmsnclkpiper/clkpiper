<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="right_col" role="main">
          <!-- top tiles -->
          
          <div class="x_title">
                  <h2>New Member</h2>
                 
                  <div class="clearfix"></div>
                </div>
          <div class="x_content">
          	<?php echo Form::open(['url'=>'administrator/member','files' => true, 'class'=>'form-horizontal']); ?>

            
          	  <div class="col-sm-12">
              	<div class="col-sm-6">
                	<div class="row">
                
                     <div class="form-group">
                        <?php echo Form::label('fname','First Name', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('fname', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('fname')?$errors->first('fname'):''; ?>

                        </div>
                    </div>
                   <div class="form-group">
                        <?php echo Form::label('lname','Last Name', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('lname', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('lname')?$errors->first('lname'):''; ?>

                        </div>
                    </div>
					 <div class="form-group">
                        <?php echo Form::label('company','Company Name', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('company', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('company')?$errors->first('company'):''; ?>

                        </div>
                    </div>
                     <div class="form-group">
                        <?php echo Form::label('email','Email Address', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::email('email', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('email')?$errors->first('email'):''; ?>

                        </div>
                    </div>
                     <div class="form-group">
                        <?php echo Form::label('password','Password', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::password('password', ['class'=>'form-control']); ?>

                            <?php echo $errors->has('password')?$errors->first('password'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('messenger','Messenger IM', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('messenger', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('messenger')?$errors->first('messenger'):''; ?>

                        </div>
                    </div>
                     <div class="form-group">
                        <?php echo Form::label('messenger_id','Mesenger IM ID', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('messenger_id', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('messenger_id')?$errors->first('messenger_id'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('phone','Phone No', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('phone', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('phone')?$errors->first('phone'):''; ?>

                        </div>
                    </div>
                     <div class="form-group">
                        <?php echo Form::label('country','Country', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            
                            <select name="country" class="form-control">
                            	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<option value="<?php echo e($count->name); ?>"><?php echo e($count->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->has('country')?$errors->first('country'):''; ?>

                        </div>
                    </div>

					
              </div>
                </div>
                <div class="col-sm-6">
                	<div class="row">
                   
                    <div class="form-group">
                        <?php echo Form::label('city','City', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('city', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('city')?$errors->first('city'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('state','State', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('state', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('state')?$errors->first('state'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('zipcode','Zip Code', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::text('zipcode', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('zipcode')?$errors->first('zipcode'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('dob','Date of Birth', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::date('dob', \Carbon\Carbon::now(), ['class'=>'form-control']); ?>

                            <?php echo $errors->has('dob')?$errors->first('dob'):''; ?>

                        </div>
                    </div>
                   
                   <div class="form-group">
                        <?php echo Form::label('address1','Address 1', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <textarea name="address1" class="form-control"></textarea>
                            <?php echo $errors->has('photo')?$errors->first('photo'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                    
                        <?php echo Form::label('photo','Address 2', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                           <textarea name="address2" class="form-control"></textarea>
                            <?php echo $errors->has('photo')?$errors->first('photo'):''; ?>

                        </div>
                    </div>
                    
                    
                    <div class="form-group">
                        <?php echo Form::label('gender','Gender', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::radio('gender', 'Male', false); ?> Male 
                            <?php echo Form::radio('gender', 'Female', false); ?> Female 
                            <?php echo $errors->has('lname')?$errors->first('lname'):''; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('photo','Photo', ['class'=>'control-label col-md-3']); ?>

                        <div class="col-md-8">
                            <?php echo Form::file('photo', null, ['class'=>'form-control']); ?>

                            <?php echo $errors->has('photo')?$errors->first('photo'):''; ?>

                        </div>
                    </div>
			

					
		
              </div>
              
                </div>
           	 
             <div class="form-group">
				<div class="col-md-10 col-md-offset-5" style="margin-top:20px;">
					<?php echo Form::submit('Save', ['class'=>'btn btn-success']); ?>

                    <?php echo Form::reset('Reset', ['class'=>'btn btn-danger']); ?>

				</div>
			</div>
              </div>
              <?php echo Form::close(); ?>	 
			</div>

          
        </div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>