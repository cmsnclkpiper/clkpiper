<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="right_col" role="main">
          <!-- top tiles -->
          
         

          <div class="row">


            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Blog List</h2>
                 
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="100%" class="table table-bordered table-striped">
                 	 <thead>
                        <tr>
                            <th>SI</th>
                            <th>Blog Title</th>
                            <th>Short Description</th>
                            <th>Photo</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                     <?php $i=1; ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    	<td><?php echo e($i++); ?></td>
                    	<td><?php echo e($menu->title); ?></td>
                        <td><?php echo e($menu->short_desc); ?></td>
                        <td><?php echo e($menu->image); ?></td>
                        <td><?php echo e($menu->created_at); ?></td>
                        <td><?php echo e($menu->updated_at); ?></td>
                        <td  align="center">
                        
                        <?php echo Form::open(['method'=>'delete', 'route'=>['blog.destroy', $menu->id]]); ?>                        
                        <a href="<?php echo e(route('blog.edit', $menu->id)); ?>" class="btn btn-warning btn-xs" style="font-size: 12px;">Edit</a>
						<?php echo Form::submit('Delete', ['class'=>'btn btn-danger btn-xs', 'onclick'=>'return confirm("Are you sure you want to delete this record?")']); ?>

						<?php echo Form::close(); ?>						
					</td>
                    </tr>
                     
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>   
                 </table>
                  

                </div>
              </div>
            </div>

         
          </div>


          
        </div>
 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>