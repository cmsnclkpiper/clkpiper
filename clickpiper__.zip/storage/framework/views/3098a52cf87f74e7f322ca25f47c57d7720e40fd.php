<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	<div class="right_col" role="main">
	<!-- top tiles -->

		<div class="x_title">
		  <h2>Edit Menu</h2>                 
		  <div class="clearfix"></div>
		</div>
		
		<div class="x_content">
			<div class="row">
				
				<?php echo Form::model($contentData, ['route'=>['contents.update', $contentData->id], 'method'=>'PATCH', 'class'=>'form-horizontal']); ?>


					<div class="form-group">
						<!-- <label class="control-label col-md-3 col-sm-3 col-xs-12" for="menuname">Menu Name <span class="required">*</span>
						</label> -->
						<?php echo Form::label('title','Title', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

						<div class="col-md-6 col-sm-6 col-xs-12">
						  <!-- <input type="text" name="menuname" required="required" class="form-control col-md-7 col-xs-12"> -->
						  <?php echo Form::text('title', null, ['class'=>'form-control col-md-7 col-xs-12']); ?>

						  <?php echo $errors->has('title')?$errors->first('title'):''; ?>

						</div>
					</div>

					<div class="form-group">
						<!-- <label class="control-label col-md-3 col-sm-3 col-xs-12" for="sequence">Sequence</span>
						</label> -->
						<?php echo Form::label('content','Content', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

						<div class="col-md-6 col-sm-6 col-xs-12">
						  <textarea name="content" class="form-control ckeditor"><?php echo e($contentData->content); ?></textarea>
						</div>
					</div>

					<div class="form-group">
	                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="menu">Menu Item</span>
	                    </label>
	                    <div class="col-md-6 col-sm-6 col-xs-12">
	                      <select name="menu_id" class="form-control">
	                        <option value="<?php echo e($contentData->menu_id); ?>"><?php echo e($menuData->menuname); ?></option>
	                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <option value="<?php echo e($menu->id); ?>"><?php echo e($menu->menuname); ?></option>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                      </select>
	                    </div>
	                    <?php if($errors->has('menu_id')): ?>
	                    <label class="col-md-3 col-sm-3 col-xs-12" style="color: red; display: inline;">
	                     <?php echo e($errors->first('menu_id')); ?>                      
	                    </label>
	                    <?php endif; ?>
	                </div>

					<div class="ln_solid"></div>
						<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <a href="<?php echo e(route('contents.index')); ?>" class="btn btn-primary">Cancel</a>
						  <?php echo Form::submit('Update', ['class'=>'btn btn-info']); ?>

						</div>
					</div>

				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>

 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>