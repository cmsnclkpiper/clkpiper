<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	<div class="right_col" role="main">
	<!-- top tiles -->

		<div class="x_title">
		  <h2>New Menu</h2>                 
		  <div class="clearfix"></div>
		</div>
		
		<div class="x_content">
			<div class="row">
				<!-- <form method="POST" action="/administrator/menus/<?php echo e($menu['id']); ?>" class="form-horizontal form-label-left"> -->
				<?php echo Form::model($menu, ['route'=>['menus.update', $menu->id], 'method'=>'PATCH', 'class'=>'form-horizontal']); ?>


					<div class="form-group">
						<!-- <label class="control-label col-md-3 col-sm-3 col-xs-12" for="menuname">Menu Name <span class="required">*</span>
						</label> -->
						<?php echo Form::label('menuname','Menu Name', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

						<div class="col-md-6 col-sm-6 col-xs-12">
						  <!-- <input type="text" name="menuname" required="required" class="form-control col-md-7 col-xs-12"> -->
						  <?php echo Form::text('menuname', null, ['class'=>'form-control col-md-7 col-xs-12']); ?>

						  <?php echo $errors->has('menuname')?$errors->first('menuname'):''; ?>

						</div>
					</div>

					<div class="form-group">
						<!-- <label class="control-label col-md-3 col-sm-3 col-xs-12" for="sequence">Sequence</span>
						</label> -->
						<?php echo Form::label('sequence','Sequence', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

						<div class="col-md-6 col-sm-6 col-xs-12">
						  <!-- <input type="text" name="sequence" required="required" class="form-control col-md-7 col-xs-12"> -->
						  <?php echo Form::text('sequence', null, ['class'=>'form-control col-md-7 col-xs-12']); ?>

						</div>
					</div>  

					<div class="form-group">
						<!-- <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status</span>
						</label> -->
						<?php echo Form::label('status','Status', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

						<div class="col-md-6 col-sm-6 col-xs-12">
						  <!-- <input type="text" name="status" required="required" class="form-control col-md-7 col-xs-12"> -->
						  <?php echo Form::text('status', null, ['class'=>'form-control col-md-7 col-xs-12']); ?>

						</div>
					</div>                         


					<div class="ln_solid"></div>
						<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <a href="<?php echo e(route('menus.index')); ?>" class="btn btn-primary">Cancel</a>
						  <?php echo Form::submit('Update', ['class'=>'btn btn-info']); ?>

						</div>
					</div>

				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>

 <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>