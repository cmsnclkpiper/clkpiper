<?php echo $__env->make('layouts.user-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
function search_offer(){
	var country = $("#country").val();	
	var category = $("#category").val();
	var date = $("#date").val();
	
	//alert(date);
	$.ajax({
		url:"<?php echo e(url('user/offer_filtering')); ?>",
		type:'GET',
		data:{'country':country,'category':category,'date':date},
		success:function(response){
			//alert(response);
			$("#responseData").html(response);
		},
		error:function(){
			alert(0);
		}
	});
}
</script>
<div id="page-wrapper" style="background-color:#ffffff !important; height:auto !important;">
            <div id="page-inner">
                    <div class="row">
                    	<div class="col-sm-8">
                         <div class="col-md-10 col-sm-12 col-xs-12 col-sm-offset-2">
                         	<h2 style="text-align:left; margin:13px">Browse Offer</h2>
                            	<div class="col-sm-10">
                                     <select name="country" id="country" class="custom-input">
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        	<option value="<?php echo e($count->name); ?>"><?php echo e($count->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>
                                </div>
                                <div class="col-sm-10">
                                	<select name="category" id="category" class="custom-input">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($count->cat_name); ?>"><?php echo e($count->cat_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-10">
                                	<input type="date" name="searchoffer" id="date" class="custom-input" placeholder="Date" style="padding:2px 5px"/>
                                </div>
                                <div class="col-sm-10">
                                	<input type="button" name="submit" class="custom-btn" onclick="search_offer();" value="Search" />
                                </div>
                         </div>
                    	
                        <div id="responseData" class="col-sm-12" style="margin-top:20px;"></div>
                    </div>
                    <!--leftbar -->
                    
                    <?php echo $__env->make('layouts.right-panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <!-- /. ROW  -->
            <!--<footer><p>Powered By: TechToday &copy 2017 <a href="#">click piper</a></p></footer>--> 
            </div>
            <!-- /. PAGE INNER  -->
        </div>


        
       
                                      	
<?php echo $__env->make('layouts.user-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>